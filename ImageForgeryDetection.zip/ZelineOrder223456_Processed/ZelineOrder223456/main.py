import cv2
from flask import Flask, jsonify, request, render_template
import base64

import cv2 as cv  # python library image processing ke liye,bohot
import numpy as np  # working with arrays;linear algebra

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/detect_forgery', methods=['POST'])
def detect_forgery():
    image1 = request.files['image1']
    image2 = request.files['image2']

    img1_bytes = image1.read()
    img2_bytes = image2.read()

    img1 = cv2.imdecode(np.frombuffer(img1_bytes, np.uint8), cv2.IMREAD_GRAYSCALE)
    img2 = cv2.imdecode(np.frombuffer(img2_bytes, np.uint8), cv2.IMREAD_GRAYSCALE)

    img1 = cv2.resize(img1, (300, 200))
    img2 = cv2.resize(img2, (300, 200))

    # Initialize SURF detector
    # surf = cv2.xfeatures2d.SIFT_create() #sift algorithm used for

    orb = cv2.ORB_create()
    kp1, des1 = orb.detectAndCompute(img1, None)
    kp2, des2 = orb.detectAndCompute(img2, None)

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # Find keypoint and descriptors in both images
    # kp1, des1 = surf.detectAndCompute(img1, None) #same function detects the keypoint and then makes the descriptors
    # kp2, des2 = surf.detectAndCompute(img2, None)

    # for d in des1: #to see that for every feature found we have an array of descriptors
    #   print(d)
    # Initialize Brute Force Matcher
    # bf = cv2.BFMatcher() #function to match descriptors by finding closest descriptor in first set to second set

    # Match descriptors
    matches = bf.match(des1, des2)

    # Sort matches by distance
    matches = sorted(matches, key=lambda x: x.distance)

    # Draw matches

    img3 = cv2.drawMatches(img1, kp1, img2, kp2, matches[:50], None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

    # Encode image to Base64 format
    _, img_data = cv2.imencode('.jpg', img3)
    img_str = base64.b64encode(img_data).decode('utf-8')

    # Display the matched image

    # cv2.imshow('Matched Features', img3)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    # Calculate average distance of matches
    distances = [match.distance for match in matches]
    avg_distance = sum(distances) / len(distances)

    # Print average distance
    # print("Average Distance: ", avg_distance)

    if avg_distance == 0:
        result = "Not forged"
    else:
        result = "Forged"

    return render_template('result.html', result=result, img_data=img_str)

if __name__ == '__main__':
    app.run(debug=True)
